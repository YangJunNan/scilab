#ifndef __LIBTOOLBOX_1_CPP_GW_HXX__
#define __LIBTOOLBOX_1_CPP_GW_HXX__

#ifdef _MSC_VER
#ifdef LIBTOOLBOX_1_CPP_GW_EXPORTS
#define LIBTOOLBOX_1_CPP_GW_IMPEXP __declspec(dllexport)
#else
#define LIBTOOLBOX_1_CPP_GW_IMPEXP __declspec(dllimport)
#endif
#else
#define LIBTOOLBOX_1_CPP_GW_IMPEXP
#endif

extern "C" LIBTOOLBOX_1_CPP_GW_IMPEXP int libtoolbox_1_cpp(wchar_t* _pwstFuncName);



#endif /* __LIBTOOLBOX_1_CPP_GW_HXX__ */
