#ifndef __TOOLBOX_1_C_GW_HXX__
#define __TOOLBOX_1_C_GW_HXX__

#ifdef _MSC_VER
#ifdef TOOLBOX_1_C_GW_EXPORTS
#define TOOLBOX_1_C_GW_IMPEXP __declspec(dllexport)
#else
#define TOOLBOX_1_C_GW_IMPEXP __declspec(dllimport)
#endif
#else
#define TOOLBOX_1_C_GW_IMPEXP
#endif

extern "C" TOOLBOX_1_C_GW_IMPEXP int toolbox_1_c(wchar_t* _pwstFuncName);



#endif /* __TOOLBOX_1_C_GW_HXX__ */
